﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection connect;
        MySqlCommand command;
        MySqlDataAdapter adapter;
        string query;
        DataTable teamhome = new DataTable();
        DataTable teamaway = new DataTable();
        DataTable match = new DataTable();
        private void Form1_Load(object sender, EventArgs e)
        {
            connect = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            connect.Open();
            connect.Close();
            try
            {
                query = "select team_name, team_id from team;";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(teamhome);
                cb_teamhome.DataSource = teamhome;
                cb_teamhome.DisplayMember = "team_name";
                cb_teamhome.ValueMember = "team_id";

                query = "select team_name, team_id from team;";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(teamaway);
                cb_teamaway.DataSource = teamaway;
                cb_teamaway.DisplayMember = "team_name";
                cb_teamaway.ValueMember = "team_id";
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable managerhome = new DataTable();
            query = $"select manager_name from manager m, team t where m.manager_id = t.manager_id AND t.team_id = '{cb_teamhome.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(managerhome);
            if (managerhome.Rows.Count != 0)
            {
                lbl_managerhome.Text = managerhome.Rows[0][0].ToString();
            }
            DataTable captainhome = new DataTable();
            query = $"select player_name from player p, team t where p.player_id = t.captain_id AND t.team_id = '{cb_teamhome.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(captainhome);
            if (captainhome.Rows.Count != 0)
            {
                lbl_captainhome.Text = captainhome.Rows[0][0].ToString();
            }
            DataTable stadium = new DataTable();
            query = $"select home_stadium from team t where t.team_id = '{cb_teamhome.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(stadium);
            if (stadium.Rows.Count != 0)
            {
                lbl_stadium.Text = stadium.Rows[0][0].ToString();
            }
            DataTable capacity = new DataTable();
            query = $"select capacity from team t where t.team_id = '{cb_teamhome.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(capacity);
            if (capacity.Rows.Count != 0)
            {
                lbl_capacity.Text = capacity.Rows[0][0].ToString();
            }

            DataTable skorhome = new DataTable();
            query = $"select goal_home from `match` m where m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(skorhome);
            if (skorhome.Rows.Count != 0)
            {
                lbl_skorhome.Text = skorhome.Rows[0][0].ToString();
            }

            DataTable skoraway = new DataTable();
            query = $"select goal_away from `match` m where m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(skoraway);
            if (skoraway.Rows.Count != 0)
            {
                lbl_skoraway.Text = skoraway.Rows[0][0].ToString();
            }

            DataTable tanggal = new DataTable();
            query = $"select date_format(match_date, '%D %M %Y') from `match` m where m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(tanggal);
            if (tanggal.Rows.Count != 0)
            {
                lbl_tanggal.Text = tanggal.Rows[0][0].ToString();
            }



        }

        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable manageraway = new DataTable();
            query = $"select manager_name from manager m, team t where m.manager_id = t.manager_id AND t.team_id = '{cb_teamaway.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(manageraway);
            if (manageraway.Rows.Count != 0)
            {
                lbl_manageraway.Text = manageraway.Rows[0][0].ToString();
            }
            DataTable captainaway = new DataTable();
            query = $"select player_name from player p, team t where p.player_id = t.captain_id AND t.team_id = '{cb_teamaway.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(captainaway);
            if (captainaway.Rows.Count != 0)
            {
                lbl_captainaway.Text = captainaway.Rows[0][0].ToString();
            }

            DataTable skorhome = new DataTable();
            query = $"select goal_home from `match` m where m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(skorhome);
            if (skorhome.Rows.Count != 0)
            {
                lbl_skorhome.Text = skorhome.Rows[0][0].ToString();
            }


            DataTable skoraway = new DataTable();
            query = $"select goal_away from `match` m where m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(skoraway);
            if (skoraway.Rows.Count != 0)
            {
                lbl_skoraway.Text = skoraway.Rows[0][0].ToString();
            }

            DataTable tanggal = new DataTable();
            query = $"select date_format(match_date, '%D %M %Y') from `match` m where m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}';";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(tanggal);
            if (tanggal.Rows.Count != 0)
            {
                lbl_tanggal.Text = tanggal.Rows[0][0].ToString();
            }



        }

        private void btn_check_Click(object sender, EventArgs e)
        {
            //DataTable datamatch = new DataTable();
            //query = $"select minute, player_name, type from dmatch d, player p, `match` m where d.player_id = p.player_id AND d.team_id = '{cb_teamhome.SelectedValue}' AND m.team_home = '{cb_teamhome.SelectedValue}' OR m.team_away = '{cb_teamaway.SelectedValue}';";
            //command = new MySqlCommand(query, connect);
            //adapter = new MySqlDataAdapter(command);
            //adapter.Fill(datamatch);
            //dgv_match.DataSource = datamatch;


        }
    }
}
