﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_teamhome = new System.Windows.Forms.ComboBox();
            this.cb_teamaway = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_check = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dgv_match = new System.Windows.Forms.DataGridView();
            this.lbl_capacity = new System.Windows.Forms.Label();
            this.lbl_stadium = new System.Windows.Forms.Label();
            this.lbl_skorhome = new System.Windows.Forms.Label();
            this.lbl_tanggal = new System.Windows.Forms.Label();
            this.lbl_captainhome = new System.Windows.Forms.Label();
            this.lbl_managerhome = new System.Windows.Forms.Label();
            this.lbl_captainaway = new System.Windows.Forms.Label();
            this.lbl_manageraway = new System.Windows.Forms.Label();
            this.lbl_mines = new System.Windows.Forms.Label();
            this.lbl_skoraway = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).BeginInit();
            this.SuspendLayout();
            // 
            // cb_teamhome
            // 
            this.cb_teamhome.FormattingEnabled = true;
            this.cb_teamhome.Location = new System.Drawing.Point(201, 80);
            this.cb_teamhome.Name = "cb_teamhome";
            this.cb_teamhome.Size = new System.Drawing.Size(292, 33);
            this.cb_teamhome.TabIndex = 0;
            this.cb_teamhome.SelectedIndexChanged += new System.EventHandler(this.cb_teamhome_SelectedIndexChanged);
            // 
            // cb_teamaway
            // 
            this.cb_teamaway.FormattingEnabled = true;
            this.cb_teamaway.Location = new System.Drawing.Point(960, 80);
            this.cb_teamaway.Name = "cb_teamaway";
            this.cb_teamaway.Size = new System.Drawing.Size(292, 33);
            this.cb_teamaway.TabIndex = 1;
            this.cb_teamaway.SelectedIndexChanged += new System.EventHandler(this.cb_teamaway_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(690, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "VS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(196, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Manager :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(196, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "Captain :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(955, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Manager :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(955, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "Captain :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(196, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 25);
            this.label6.TabIndex = 7;
            this.label6.Text = "Home";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(955, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 25);
            this.label7.TabIndex = 8;
            this.label7.Text = "Away";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(539, 331);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 25);
            this.label8.TabIndex = 10;
            this.label8.Text = "Capacity :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(539, 279);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 25);
            this.label9.TabIndex = 9;
            this.label9.Text = "Stadium :";
            // 
            // btn_check
            // 
            this.btn_check.Location = new System.Drawing.Point(645, 389);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(144, 55);
            this.btn_check.TabIndex = 11;
            this.btn_check.Text = "Check";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_check_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(573, 512);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 25);
            this.label10.TabIndex = 13;
            this.label10.Text = "Skor :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(539, 467);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 25);
            this.label11.TabIndex = 12;
            this.label11.Text = "Tanggal :";
            // 
            // dgv_match
            // 
            this.dgv_match.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_match.Location = new System.Drawing.Point(201, 589);
            this.dgv_match.Name = "dgv_match";
            this.dgv_match.RowHeadersWidth = 82;
            this.dgv_match.RowTemplate.Height = 33;
            this.dgv_match.Size = new System.Drawing.Size(1185, 446);
            this.dgv_match.TabIndex = 14;
            // 
            // lbl_capacity
            // 
            this.lbl_capacity.AutoSize = true;
            this.lbl_capacity.Location = new System.Drawing.Point(673, 331);
            this.lbl_capacity.Name = "lbl_capacity";
            this.lbl_capacity.Size = new System.Drawing.Size(19, 25);
            this.lbl_capacity.TabIndex = 16;
            this.lbl_capacity.Text = "-";
            // 
            // lbl_stadium
            // 
            this.lbl_stadium.AutoSize = true;
            this.lbl_stadium.Location = new System.Drawing.Point(673, 279);
            this.lbl_stadium.Name = "lbl_stadium";
            this.lbl_stadium.Size = new System.Drawing.Size(19, 25);
            this.lbl_stadium.TabIndex = 15;
            this.lbl_stadium.Text = "-";
            // 
            // lbl_skorhome
            // 
            this.lbl_skorhome.AutoSize = true;
            this.lbl_skorhome.Location = new System.Drawing.Point(673, 519);
            this.lbl_skorhome.Name = "lbl_skorhome";
            this.lbl_skorhome.Size = new System.Drawing.Size(19, 25);
            this.lbl_skorhome.TabIndex = 18;
            this.lbl_skorhome.Text = "-";
            // 
            // lbl_tanggal
            // 
            this.lbl_tanggal.AutoSize = true;
            this.lbl_tanggal.Location = new System.Drawing.Point(673, 467);
            this.lbl_tanggal.Name = "lbl_tanggal";
            this.lbl_tanggal.Size = new System.Drawing.Size(19, 25);
            this.lbl_tanggal.TabIndex = 17;
            this.lbl_tanggal.Text = "-";
            // 
            // lbl_captainhome
            // 
            this.lbl_captainhome.AutoSize = true;
            this.lbl_captainhome.Location = new System.Drawing.Point(323, 206);
            this.lbl_captainhome.Name = "lbl_captainhome";
            this.lbl_captainhome.Size = new System.Drawing.Size(19, 25);
            this.lbl_captainhome.TabIndex = 20;
            this.lbl_captainhome.Text = "-";
            // 
            // lbl_managerhome
            // 
            this.lbl_managerhome.AutoSize = true;
            this.lbl_managerhome.Location = new System.Drawing.Point(323, 154);
            this.lbl_managerhome.Name = "lbl_managerhome";
            this.lbl_managerhome.Size = new System.Drawing.Size(19, 25);
            this.lbl_managerhome.TabIndex = 19;
            this.lbl_managerhome.Text = "-";
            // 
            // lbl_captainaway
            // 
            this.lbl_captainaway.AutoSize = true;
            this.lbl_captainaway.Location = new System.Drawing.Point(1081, 206);
            this.lbl_captainaway.Name = "lbl_captainaway";
            this.lbl_captainaway.Size = new System.Drawing.Size(19, 25);
            this.lbl_captainaway.TabIndex = 22;
            this.lbl_captainaway.Text = "-";
            // 
            // lbl_manageraway
            // 
            this.lbl_manageraway.AutoSize = true;
            this.lbl_manageraway.Location = new System.Drawing.Point(1081, 154);
            this.lbl_manageraway.Name = "lbl_manageraway";
            this.lbl_manageraway.Size = new System.Drawing.Size(19, 25);
            this.lbl_manageraway.TabIndex = 21;
            this.lbl_manageraway.Text = "-";
            // 
            // lbl_mines
            // 
            this.lbl_mines.AutoSize = true;
            this.lbl_mines.Location = new System.Drawing.Point(740, 519);
            this.lbl_mines.Name = "lbl_mines";
            this.lbl_mines.Size = new System.Drawing.Size(19, 25);
            this.lbl_mines.TabIndex = 23;
            this.lbl_mines.Text = "-";
            // 
            // lbl_skoraway
            // 
            this.lbl_skoraway.AutoSize = true;
            this.lbl_skoraway.Location = new System.Drawing.Point(806, 519);
            this.lbl_skoraway.Name = "lbl_skoraway";
            this.lbl_skoraway.Size = new System.Drawing.Size(19, 25);
            this.lbl_skoraway.TabIndex = 24;
            this.lbl_skoraway.Text = "-";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1642, 1158);
            this.Controls.Add(this.lbl_skoraway);
            this.Controls.Add(this.lbl_mines);
            this.Controls.Add(this.lbl_captainaway);
            this.Controls.Add(this.lbl_manageraway);
            this.Controls.Add(this.lbl_captainhome);
            this.Controls.Add(this.lbl_managerhome);
            this.Controls.Add(this.lbl_skorhome);
            this.Controls.Add(this.lbl_tanggal);
            this.Controls.Add(this.lbl_capacity);
            this.Controls.Add(this.lbl_stadium);
            this.Controls.Add(this.dgv_match);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_teamaway);
            this.Controls.Add(this.cb_teamhome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb_teamhome;
        private System.Windows.Forms.ComboBox cb_teamaway;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dgv_match;
        private System.Windows.Forms.Label lbl_capacity;
        private System.Windows.Forms.Label lbl_stadium;
        private System.Windows.Forms.Label lbl_skorhome;
        private System.Windows.Forms.Label lbl_tanggal;
        private System.Windows.Forms.Label lbl_captainhome;
        private System.Windows.Forms.Label lbl_managerhome;
        private System.Windows.Forms.Label lbl_captainaway;
        private System.Windows.Forms.Label lbl_manageraway;
        private System.Windows.Forms.Label lbl_mines;
        private System.Windows.Forms.Label lbl_skoraway;
    }
}

